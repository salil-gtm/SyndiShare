python-multihash
================

Multihash implementation in Python. For more information, refer to the
multihash project page at https://github.com/jbenet/multihash/
