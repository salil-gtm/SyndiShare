Release Notes
=============

.. _v0.4.8-release-notes:

0.4.8
-----

- Implement ``Serializable.make_mutable`` and ``rlp.sedes.make_mutable`` API.
- Add ``mutable`` flag to ``Serializable.deserialize`` to allow deserialization into mutable objects.
