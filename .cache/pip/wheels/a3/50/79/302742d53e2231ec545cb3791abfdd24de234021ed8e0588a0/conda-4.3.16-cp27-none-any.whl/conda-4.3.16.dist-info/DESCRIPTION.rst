.. image:: https://s3.amazonaws.com/conda-dev/conda_logo.svg
   :alt: Conda Logo

Conda is a cross-platform, language-agnostic binary package manager. It is the
package manager used by `Anaconda
<http://docs.continuum.io/anaconda/index.html>`_ installations, but it may be
used for other systems as well.  Conda makes environments first-class
citizens, making it easy to create independent environments even for C
libraries. Conda is written entirely in Python, and is BSD licensed open
source.


Installation
############

**WARNING:** Using ``pip install conda`` or ``easy_install conda`` will not
give you conda as a standalone application.  Currently supported install
methods include the Anaconda installer and the miniconda installer.  You
can download the miniconda installer from https://conda.io/miniconda.html.



