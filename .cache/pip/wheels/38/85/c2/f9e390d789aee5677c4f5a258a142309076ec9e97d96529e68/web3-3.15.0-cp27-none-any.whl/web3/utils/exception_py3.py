def raise_from(my_exception, other_exception):
    raise my_exception from other_exception
